#!/bin/bash

SDL_VIDEODRIVER=offscreen /opt/carla-simulator/CarlaUE4.sh -opengl&
